package io.swagger.client.controller;

import java.io.IOException;
import java.io.Writer;
import java.sql.Timestamp;
import java.util.Hashtable;

import javax.validation.Valid;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.xml.sax.SAXException;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.ibm.mq.MQC;
import com.ibm.mq.MQException;
import com.ibm.mq.MQGetMessageOptions;
import com.ibm.mq.MQMessage;
import com.ibm.mq.MQPutMessageOptions;
import com.ibm.mq.MQQueueManager;
import com.ibm.mq.constants.MQConstants;
import com.ibm.mq.jms.MQQueueConnectionFactory;

import io.swagger.client.model.Document;
@Configuration
@EnableTransactionManagement

@CrossOrigin(origins = "*", maxAge = 3600)
@RequestMapping(path="/getLiquidityPosition/V1")
@RestController
public class GetLiquidityPositionController 
{
	 private static final Logger logger = LogManager.getLogger(GetLiquidityPositionController.class);
	@Value("${project.mq.host}")
    private String host;
    @Value("${project.mq.port}")
    private Integer port;
    @Value("${project.mq.queuemanager}")
    private String queueManager;
    @Value("${project.mq.channel}")
    private String channel;
    @Value("${project.mq.username}")
    private String username;
    @Value("${project.mq.password}")
    private String password;
    @Value("${project.mq.queue}")
    private String queuereq;
    @Value("${project.mq.rplyqueue}")
    private String rplyqueuereq;
    @Value("${project.mq.receive-timeout}")
    private long receiveTimeout;

	private Document document;
	private String RespMessage;
	String schemaData ;
	JsonGenerator g ;
	Writer w;
	 public byte[] Stringtobytearray(String msgId) {

		 String str = msgId;

		  byte[] b = str.getBytes();

		  return b;

     	

     }

	MQQueueConnectionFactory cf = new MQQueueConnectionFactory(); 
	ErrorHandling errohandling = new ErrorHandling();

    @PostMapping(path="/Getliquidityposition",consumes="application/json", produces="application/json")


    public ResponseEntity<String> Paymeth(@Valid @RequestBody Document request ) throws IOException, SAXException, ParserConfigurationException, MQException, ClassNotFoundException{

    	ObjectMapper objectMapper = new XmlMapper();


        String reqMsg = objectMapper.writeValueAsString(request);

        String MsgId=org.apache.commons.lang3.StringUtils.substringBetween(reqMsg,"<MsgId>", "</MsgId>");
      //  MsgId= MsgId + 
     
   
        String finalstr= reqMsg.replaceAll("<Document xmlns=\"\">"," ");
        String finalReq= finalstr.replaceFirst("</Document>", " ");
        Timestamp timestamp = new Timestamp(System.currentTimeMillis());

		System.out.println("timestamp"+timestamp);
        System.out.println("Request message"+finalReq);
        logger.info("MsgId="+MsgId+"Msg="+finalReq);
        logger.error("MsgId="+MsgId+"Msg="+finalReq);

        	Hashtable<String, Object> props = new Hashtable<String, Object>();
            props.put(MQConstants.CHANNEL_PROPERTY, channel);
            props.put(MQConstants.PORT_PROPERTY, port);
            props.put(MQConstants.HOST_NAME_PROPERTY, host);
            props.put(MQConstants.USER_ID_PROPERTY,username);
            props.put(MQConstants.PASSWORD_PROPERTY, password);

            MQQueueManager qMgr = null;

           try { 
        	   qMgr = new MQQueueManager(queueManager, props);
        	   int openOptions = MQConstants.MQOO_OUTPUT | MQConstants.MQOO_INPUT_AS_Q_DEF;
        	   com.ibm.mq.MQQueue queue = qMgr.accessQueue(queuereq, openOptions);
        	   MQPutMessageOptions pmo = new MQPutMessageOptions(); 
        	   pmo.options = MQConstants.MQPMO_ASYNC_RESPONSE;
        	   MQMessage message = new MQMessage();
        	   message.messageId = Stringtobytearray(MsgId+timestamp);

        	   System.out.println(Stringtobytearray(MsgId+timestamp));


        	   message.format = MQConstants.MQFMT_STRING;
        	   message.characterSet = 1208;
               message.writeString(finalReq);
               queue.put(message, pmo);
               queue.close();
           }catch (MQException jmsex) {
 	    	   System.out.println(jmsex);
 	    	   System.out.println("Message Send Failure\n");
 	       }finally {
 	             qMgr.disconnect();
 	       }

          //////////////////////////Get Message From Queue//////////////////////////////////////
           try { 
        	   qMgr = new MQQueueManager(queueManager, props);
        	   int openOptions = MQConstants.MQOO_OUTPUT | MQConstants.MQOO_INPUT_AS_Q_DEF;
        	   com.ibm.mq.MQQueue queue = qMgr.accessQueue(queuereq, openOptions);
        	   MQPutMessageOptions pmo = new MQPutMessageOptions(); 
        	   pmo.options = MQConstants.MQPMO_ASYNC_RESPONSE;
        	   MQMessage messageReply = new MQMessage();

        	   MQGetMessageOptions gmo = new MQGetMessageOptions();
        	   gmo.options = gmo.options + MQC.MQGMO_WAIT;
        	   gmo.waitInterval=20000;

        	   gmo.matchOptions=MQC.MQMO_MATCH_CORREL_ID;

        	   //gmo.options = MQC.MQGMO_FAIL_IF_QUIESCING + MQC.MQGMO_CONVERT;

        	   messageReply.correlationId = Stringtobytearray(MsgId+timestamp);

        	   
        	   com.ibm.mq.MQQueue queueReply = qMgr.accessQueue(rplyqueuereq, openOptions);
        	   queueReply.get(messageReply, gmo);
        	   int len =   messageReply.getDataLength();     	   
        	   RespMessage = messageReply.readStringOfByteLength(len);
        	   System.out.println(RespMessage);
        	   logger.error("MsgId="+MsgId+"Msg="+RespMessage);
        	   queueReply.close();

           }catch (MQException jmsex) {
 	    	   System.out.println(jmsex);
 	    	   System.out.println("Message Get Failure\n");
 	       }finally {
	             qMgr.disconnect();
	       }

    	XmlMapper xmlMapper = new XmlMapper();
    	xmlMapper.registerModule(new SimpleModule().addDeserializer(
    		    JsonNode.class, 
    		    new DuplicateToArrayJsonNodeDeserializer()
    		));
    	
    	JsonNode jsonNode = xmlMapper.readTree(RespMessage);

		 ObjectMapper objectMapper1 = new ObjectMapper();

		 String value = "{\"Document\": " + objectMapper1.writeValueAsString(jsonNode) +"}";
    	return new ResponseEntity<>(value,HttpStatus.OK);
	

}
}