package io.swagger.client.api;

public class ERRORUNKNOWN {

}
