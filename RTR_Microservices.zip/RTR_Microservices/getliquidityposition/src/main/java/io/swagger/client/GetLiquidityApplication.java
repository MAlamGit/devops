package io.swagger.client;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class GetLiquidityApplication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SpringApplication.run(GetLiquidityApplication.class, args);
	}

}
