
# GenericFinancialIdentification1

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  | 
**schmeNm** | **Object** |  |  [optional]
**issr** | **String** |  |  [optional]



