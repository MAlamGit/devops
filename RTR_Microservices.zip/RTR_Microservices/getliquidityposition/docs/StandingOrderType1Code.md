
# StandingOrderType1Code

## Enum


* `USTO` (value: `"USTO"`)

* `PSTO` (value: `"PSTO"`)



