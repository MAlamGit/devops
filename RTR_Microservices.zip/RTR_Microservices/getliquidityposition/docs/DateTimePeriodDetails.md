
# DateTimePeriodDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**frDtTm** | **String** |  | 
**toDtTm** | **String** |  | 



