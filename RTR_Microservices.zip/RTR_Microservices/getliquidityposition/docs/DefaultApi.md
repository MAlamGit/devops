# DefaultApi

All URIs are relative to *http://localhost/getLiquidityPosition/V1/*

Method | HTTP request | Description
------------- | ------------- | -------------
[**createPayment**](DefaultApi.md#createPayment) | **POST** /getLiquidityPositions | Create a new payment


<a name="createPayment"></a>
# **createPayment**
> ERRORUNKNOWN createPayment(document)

Create a new payment

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DefaultApi;


DefaultApi apiInstance = new DefaultApi();
Document document = new Document(); // Document | Document
try {
    ERRORUNKNOWN result = apiInstance.createPayment(document);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DefaultApi#createPayment");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **document** | [**Document**](Document.md)| Document |

### Return type

[**ERRORUNKNOWN**](ERRORUNKNOWN.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

