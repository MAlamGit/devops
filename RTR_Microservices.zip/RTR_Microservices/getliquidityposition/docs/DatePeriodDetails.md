
# DatePeriodDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**frDt** | **String** |  | 
**toDt** | **String** |  | 



