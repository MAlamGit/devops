
# AccountQuery1

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**qryTp** | **Object** |  |  [optional]
**acctCrit** | **Object** |  |  [optional]



