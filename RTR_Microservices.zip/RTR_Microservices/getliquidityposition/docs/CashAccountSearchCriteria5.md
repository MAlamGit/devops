
# CashAccountSearchCriteria5

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**acctId** | **Object** |  |  [optional]
**tp** | **Object** |  |  [optional]
**ccy** | **Object** |  |  [optional]
**bal** | **Object** |  |  [optional]
**acctOwnr** | **Object** |  |  [optional]
**acctSvcr** | **Object** |  |  [optional]



