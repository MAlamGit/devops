
# EventType1Choice

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cd** | **String** |  | 
**prtry** | **String** |  | 



