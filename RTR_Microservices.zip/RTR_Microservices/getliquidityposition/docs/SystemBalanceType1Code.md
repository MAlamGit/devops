
# SystemBalanceType1Code

## Enum


* `OPNG` (value: `"OPNG"`)

* `INTM` (value: `"INTM"`)

* `CLSG` (value: `"CLSG"`)

* `BOOK` (value: `"BOOK"`)

* `CRRT` (value: `"CRRT"`)

* `PDNG` (value: `"PDNG"`)

* `LRLD` (value: `"LRLD"`)

* `AVLB` (value: `"AVLB"`)

* `LTSF` (value: `"LTSF"`)

* `CRDT` (value: `"CRDT"`)

* `EAST` (value: `"EAST"`)

* `PYMT` (value: `"PYMT"`)

* `BLCK` (value: `"BLCK"`)

* `XPCD` (value: `"XPCD"`)

* `DLOD` (value: `"DLOD"`)

* `XCRD` (value: `"XCRD"`)

* `XDBT` (value: `"XDBT"`)

* `ADJT` (value: `"ADJT"`)

* `PRAV` (value: `"PRAV"`)

* `DBIT` (value: `"DBIT"`)

* `THRE` (value: `"THRE"`)

* `NOTE` (value: `"NOTE"`)

* `SELF` (value: `"SELF"`)

* `MSTR` (value: `"MSTR"`)

* `FSET` (value: `"FSET"`)

* `BLOC` (value: `"BLOC"`)

* `OTHB` (value: `"OTHB"`)

* `CUST` (value: `"CUST"`)

* `FORC` (value: `"FORC"`)

* `COLC` (value: `"COLC"`)

* `FUND` (value: `"FUND"`)

* `PIPO` (value: `"PIPO"`)

* `XCHG` (value: `"XCHG"`)

* `CCPS` (value: `"CCPS"`)

* `TOHB` (value: `"TOHB"`)

* `COHB` (value: `"COHB"`)

* `DOHB` (value: `"DOHB"`)

* `TPBL` (value: `"TPBL"`)

* `CPBL` (value: `"CPBL"`)

* `DPBL` (value: `"DPBL"`)

* `FUTB` (value: `"FUTB"`)

* `REJB` (value: `"REJB"`)

* `FCOL` (value: `"FCOL"`)

* `FCOU` (value: `"FCOU"`)

* `SCOL` (value: `"SCOL"`)

* `SCOU` (value: `"SCOU"`)

* `CUSA` (value: `"CUSA"`)

* `XCHC` (value: `"XCHC"`)

* `XCHN` (value: `"XCHN"`)

* `DSET` (value: `"DSET"`)

* `LACK` (value: `"LACK"`)

* `NSET` (value: `"NSET"`)

* `OTCC` (value: `"OTCC"`)

* `OTCG` (value: `"OTCG"`)

* `OTCN` (value: `"OTCN"`)

* `SAPD` (value: `"SAPD"`)

* `SAPC` (value: `"SAPC"`)

* `REPD` (value: `"REPD"`)

* `REPC` (value: `"REPC"`)

* `BSCD` (value: `"BSCD"`)

* `BSCC` (value: `"BSCC"`)

* `SAPP` (value: `"SAPP"`)

* `IRLT` (value: `"IRLT"`)

* `IRDR` (value: `"IRDR"`)

* `DWRD` (value: `"DWRD"`)

* `ADWR` (value: `"ADWR"`)

* `AIDR` (value: `"AIDR"`)

* `REST` (value: `"REST"`)



