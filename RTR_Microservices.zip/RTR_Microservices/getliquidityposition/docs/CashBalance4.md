
# CashBalance4

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**tp** | **Object** |  |  [optional]
**ctrPtyTp** | **Object** |  | 
**ctrPtyId** | **Object** |  |  [optional]
**valDt** | **Object** |  |  [optional]



