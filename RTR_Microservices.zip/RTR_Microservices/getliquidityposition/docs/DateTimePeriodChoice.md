
# DateTimePeriodChoice

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**frDtTm** | **String** |  | 
**toDtTm** | **String** |  | 
**dtTmRg** | **Object** |  | 



