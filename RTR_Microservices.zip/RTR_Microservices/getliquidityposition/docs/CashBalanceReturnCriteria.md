
# CashBalanceReturnCriteria

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**tpInd** | **String** |  | 
**stsInd** | **String** |  | 
**valDtInd** | **String** |  | 
**nbOfPmtsInd** | **String** |  | 



