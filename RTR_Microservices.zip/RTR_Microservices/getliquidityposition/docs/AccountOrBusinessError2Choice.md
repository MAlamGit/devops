
# AccountOrBusinessError2Choice

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**acct** | **Object** |  | 
**bizErr** | **Object** |  | 



