
# NamePrefix1Code

## Enum


* `DOCT` (value: `"DOCT"`)

* `MIST` (value: `"MIST"`)

* `MISS` (value: `"MISS"`)

* `MADM` (value: `"MADM"`)



