
# FinancialInstitutionIdentification8

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**bicfi** | **String** |  |  [optional]
**clrSysMmbId** | **Object** |  |  [optional]
**nm** | **String** |  |  [optional]
**pstlAdr** | **Object** |  |  [optional]
**othr** | **Object** |  |  [optional]



