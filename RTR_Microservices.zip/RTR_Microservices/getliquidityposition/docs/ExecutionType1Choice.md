
# ExecutionType1Choice

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**tm** | **Object** |  | 
**evt** | **Object** |  | 



