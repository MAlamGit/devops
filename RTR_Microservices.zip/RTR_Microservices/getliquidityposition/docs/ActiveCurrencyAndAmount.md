
# ActiveCurrencyAndAmount

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **String** |  |  [optional]
**ccy** | **String** |  | 



