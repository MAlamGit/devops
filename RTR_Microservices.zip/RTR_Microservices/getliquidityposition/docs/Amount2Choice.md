
# Amount2Choice

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amtWthtCcy** | **String** |  | 
**amtWthCcy** | **Object** |  | 



