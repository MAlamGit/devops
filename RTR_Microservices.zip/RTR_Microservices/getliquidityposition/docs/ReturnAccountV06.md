
# ReturnAccountV06

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**msgHdr** | **Object** |  | 
**rptOrErr** | **Object** |  | 



