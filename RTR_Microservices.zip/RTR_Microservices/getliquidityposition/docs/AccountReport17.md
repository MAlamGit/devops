
# AccountReport17

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**acctId** | **Object** |  | 
**acctOrErr** | **Object** |  | 



