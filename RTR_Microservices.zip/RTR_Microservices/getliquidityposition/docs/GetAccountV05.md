
# GetAccountV05

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**msgHdr** | **Object** |  | 
**acctQryDef** | **Object** |  |  [optional]



