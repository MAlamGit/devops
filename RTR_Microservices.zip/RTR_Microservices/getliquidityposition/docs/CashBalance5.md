
# CashBalance5

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amt** | **String** |  | 
**cdtDbtInd** | **Object** |  | 
**tp** | **Object** |  |  [optional]
**sts** | **Object** |  |  [optional]
**valDt** | **Object** |  |  [optional]
**nbOfPmts** | **String** |  |  [optional]
**rstrctnTp** | **Object** |  |  [optional]



