
# PartyIdentification43

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nm** | **String** |  |  [optional]
**pstlAdr** | **Object** |  |  [optional]
**id** | **Object** |  |  [optional]
**ctryOfRes** | **String** |  |  [optional]
**ctctDtls** | **Object** |  |  [optional]



