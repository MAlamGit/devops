
# StandingOrder2

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amt** | **Object** |  | 
**cdtDbtInd** | **Object** |  | 
**ccy** | **String** |  |  [optional]
**tp** | **Object** |  |  [optional]
**assoctdPoolAcct** | **Object** |  |  [optional]
**ref** | **String** |  |  [optional]
**frqcy** | **Object** |  |  [optional]
**vldtyPrd** | **Object** |  |  [optional]
**sysMmb** | **Object** |  |  [optional]
**rspnsblPty** | **Object** |  |  [optional]
**lkSetId** | **String** |  |  [optional]
**lkSetOrdrId** | **String** |  |  [optional]
**lkSetOrdrSeq** | **String** |  |  [optional]
**exctnTp** | **Object** |  |  [optional]
**cdtrAcct** | **Object** |  |  [optional]
**dbtrAcct** | **Object** |  |  [optional]
**ttlsPerStgOrdr** | **Object** |  |  [optional]
**zeroSweepInd** | **String** |  |  [optional]



