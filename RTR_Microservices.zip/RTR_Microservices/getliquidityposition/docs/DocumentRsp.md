
# DocumentRsp

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**rtrAcct** | **Object** |  | 



