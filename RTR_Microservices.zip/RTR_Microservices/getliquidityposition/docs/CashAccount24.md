
# CashAccount24

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Object** |  | 
**tp** | **Object** |  |  [optional]
**ccy** | **String** |  |  [optional]
**nm** | **String** |  |  [optional]



