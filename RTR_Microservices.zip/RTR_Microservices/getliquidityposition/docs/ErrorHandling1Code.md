
# ErrorHandling1Code

## Enum


* `X020` (value: `"X020"`)

* `X030` (value: `"X030"`)

* `X050` (value: `"X050"`)



