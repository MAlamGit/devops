
# CashAccountReturnCriteria3

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nmInd** | **String** |  |  [optional]
**ccyInd** | **String** |  |  [optional]
**tpInd** | **String** |  |  [optional]
**mulLmtInd** | **String** |  |  [optional]
**mulBalRtrCrit** | **Object** |  |  [optional]
**bilLmtInd** | **String** |  |  [optional]
**bilBalRtrCrit** | **Object** |  |  [optional]
**stgOrdrInd** | **String** |  |  [optional]
**acctOwnrInd** | **String** |  |  [optional]
**acctSvcrInd** | **String** |  |  [optional]



