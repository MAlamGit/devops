
# Time

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------



