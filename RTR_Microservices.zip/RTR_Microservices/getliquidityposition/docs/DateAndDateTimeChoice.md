
# DateAndDateTimeChoice

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**dt** | **String** |  | 
**dtTm** | **String** |  | 



