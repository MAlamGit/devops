
# MessageHeader3

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**msgId** | **String** |  | 
**creDtTm** | **String** |  |  [optional]
**reqTp** | **Object** |  |  [optional]
**orgnlBizQry** | **Object** |  |  [optional]
**qryNm** | **String** |  |  [optional]



