
# BilateralLimit1

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ctrPtyId** | **Object** |  | 
**lmtAmt** | **Object** |  | 
**cdtDbtInd** | **Object** |  | 
**bilBal** | **Object** |  |  [optional]



