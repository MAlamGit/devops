
# ErrorHandling4

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**err** | **Object** |  | 
**desc** | **String** |  |  [optional]



