
# CashAccount23

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nm** | **String** |  |  [optional]
**tp** | **Object** |  |  [optional]
**ccy** | **String** |  |  [optional]
**curMulLmt** | **Object** |  |  [optional]
**ownr** | **Object** |  |  [optional]
**svcr** | **Object** |  |  [optional]
**mulBal** | **Object** |  |  [optional]
**curBilLmt** | **Object** |  |  [optional]
**stgOrdr** | **Object** |  |  [optional]



