
# CreditDebitCode

## Enum


* `CRDT` (value: `"CRDT"`)

* `DBIT` (value: `"DBIT"`)



