
# TotalAmountAndCurrency1

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ttlAmt** | **String** |  | 
**cdtDbtInd** | **Object** |  |  [optional]
**ccy** | **String** |  |  [optional]



