
# BalanceStatus1Code

## Enum


* `PDNG` (value: `"PDNG"`)

* `STLD` (value: `"STLD"`)



