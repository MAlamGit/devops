
# AccountCriteria5

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**newQryNm** | **String** |  |  [optional]
**schCrit** | **Object** |  |  [optional]
**rtrCrit** | **Object** |  |  [optional]



