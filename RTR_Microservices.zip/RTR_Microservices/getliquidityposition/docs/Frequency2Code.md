
# Frequency2Code

## Enum


* `YEAR` (value: `"YEAR"`)

* `MNTH` (value: `"MNTH"`)

* `QURT` (value: `"QURT"`)

* `MIAN` (value: `"MIAN"`)

* `WEEK` (value: `"WEEK"`)

* `DAIL` (value: `"DAIL"`)

* `ADHO` (value: `"ADHO"`)

* `INDA` (value: `"INDA"`)

* `OVNG` (value: `"OVNG"`)



