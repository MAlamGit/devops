
# QueryType2Code

## Enum


* `ALLL` (value: `"ALLL"`)

* `CHNG` (value: `"CHNG"`)

* `MODF` (value: `"MODF"`)

* `DELD` (value: `"DELD"`)



