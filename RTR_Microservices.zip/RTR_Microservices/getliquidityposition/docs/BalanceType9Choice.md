
# BalanceType9Choice

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cd** | **Object** |  | 
**prtry** | **String** |  | 



