
# StandingOrderTotalAmount1

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**setPrdfndOrdr** | **Object** |  | 
**pdgPrdfndOrdr** | **Object** |  | 
**setStgOrdr** | **Object** |  | 
**pdgStgOrdr** | **Object** |  | 



