
# ClearingSystemMemberIdentification2

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**clrSysId** | **Object** |  |  [optional]
**mmbId** | **String** |  | 



