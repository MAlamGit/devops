
# BranchAndFinancialInstitutionIdentification5

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**finInstnId** | **Object** |  | 
**brnchId** | **Object** |  |  [optional]



