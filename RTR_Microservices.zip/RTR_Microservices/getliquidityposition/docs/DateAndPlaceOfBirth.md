
# DateAndPlaceOfBirth

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**birthDt** | **String** |  | 
**prvcOfBirth** | **String** |  |  [optional]
**cityOfBirth** | **String** |  | 
**ctryOfBirth** | **String** |  | 



