
# AccountCriteria1Choice

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**qryNm** | **String** |  | 
**newCrit** | **Object** |  | 



