
# OriginalBusinessQuery1

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**msgId** | **String** |  | 
**msgNmId** | **String** |  |  [optional]
**creDtTm** | **String** |  |  [optional]



