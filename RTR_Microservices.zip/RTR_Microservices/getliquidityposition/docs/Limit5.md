
# Limit5

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amt** | **Object** |  | 
**cdtDbtInd** | **Object** |  | 



