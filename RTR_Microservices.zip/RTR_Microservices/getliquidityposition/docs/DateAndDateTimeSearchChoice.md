
# DateAndDateTimeSearchChoice

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**dtTmSch** | **Object** |  | 
**dtSch** | **Object** |  | 



