
# PersonIdentification5

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**dtAndPlcOfBirth** | **Object** |  |  [optional]
**othr** | **Object** |  |  [optional]



