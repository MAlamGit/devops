
# AccountOrOperationalError2Choice

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**acctRpt** | **Object** |  | 
**oprlErr** | **Object** |  | 



