
# RequestType2Choice

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**pmtCtrl** | **Object** |  | 
**enqry** | **Object** |  | 
**prtry** | **Object** |  | 



