
# BalanceCounterparty1Code

## Enum


* `BILA` (value: `"BILA"`)

* `MULT` (value: `"MULT"`)



