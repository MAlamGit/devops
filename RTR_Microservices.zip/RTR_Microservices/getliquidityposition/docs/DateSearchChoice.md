
# DateSearchChoice

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**frDt** | **String** |  | 
**toDt** | **String** |  | 
**frToDt** | **Object** |  | 
**eqDt** | **String** |  | 
**neqDt** | **String** |  | 



