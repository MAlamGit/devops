
# ProcessingType1Code

## Enum


* `RJCT` (value: `"RJCT"`)

* `CVHD` (value: `"CVHD"`)

* `RSVT` (value: `"RSVT"`)

* `BLCK` (value: `"BLCK"`)

* `EARM` (value: `"EARM"`)

* `EFAC` (value: `"EFAC"`)

* `DLVR` (value: `"DLVR"`)

* `COLD` (value: `"COLD"`)

* `CSDB` (value: `"CSDB"`)



