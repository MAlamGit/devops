
# BalanceRestrictionType1

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**tp** | **Object** |  | 
**desc** | **String** |  |  [optional]
**prcgTp** | **Object** |  |  [optional]



