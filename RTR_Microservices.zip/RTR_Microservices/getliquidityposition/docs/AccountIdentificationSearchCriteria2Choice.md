
# AccountIdentificationSearchCriteria2Choice

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**eq** | **Object** |  | 
**ctTxt** | **String** |  | 
**nctTxt** | **String** |  | 



