
# DatePeriodDetails1

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**frDt** | **String** |  | 
**toDt** | **String** |  |  [optional]



