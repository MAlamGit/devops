package io.swagger.client.controller;

import java.io.IOException;
import java.util.ArrayList;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;

import io.swagger.client.model.AdditionalDetails;
import io.swagger.client.model.Document;
import io.swagger.client.model.Error;
import io.swagger.client.model.Error.SeverityEnum;
import io.swagger.client.model.ErrorResponse;

/*
 *Error Handling for Manage Liquidity service  
 */
@Component
public class ErrorHandling {

	ErrorResponse errorResponse = new ErrorResponse();
	Error error = new Error();
	AdditionalDetails additionalDetails = new AdditionalDetails();
	ArrayList<AdditionalDetails> alist = new ArrayList<AdditionalDetails>();

	public ErrorResponse errorhandler(Exception e) {
		if (e.getMessage().contains("JMS")) {

			additionalDetails.setDescription(e.getMessage());
			additionalDetails.setErrorCode("0");
			additionalDetails.setSeverity("error");
			alist.add(additionalDetails);
			error.setCode("301");
			error.setSeverity(SeverityEnum.ERROR);
			error.setErrordescription(e.getMessage());
			error.setAdditionalDetails(alist);
			errorResponse.setError(error);
			errorResponse.setFatalError(true);
		}
		return errorResponse;
	}

	public ErrorResponse isJSONValid(Document request) {
		try {
			final ObjectMapper mapper = new ObjectMapper();
			mapper.readTree(request.toString());

		} catch (IOException e) {
			return errorResponse;

		}
		return errorResponse;

	}
}
