# DefaultApi

All URIs are relative to *http://localhost/manageLiquidityAccount/V1/*

Method | HTTP request | Description
------------- | ------------- | -------------
[**createPayment**](DefaultApi.md#createPayment) | **POST** /manageLiquidityAccount | Create a new payment


<a name="createPayment"></a>
# **createPayment**
> InlineResponse200 createPayment(document)

Create a new payment

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DefaultApi;


DefaultApi apiInstance = new DefaultApi();
Document document = new Document(); // Document | Document
try {
    InlineResponse200 result = apiInstance.createPayment(document);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DefaultApi#createPayment");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **document** | [**Document**](Document.md)| Document |

### Return type

[**InlineResponse200**](InlineResponse200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

