
# PartyAndAuthorisation1

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sgntrOrdr** | **String** |  |  [optional]



