
# PartyAndCertificate2

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------



