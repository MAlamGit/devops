
# References5

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sts** | **String** |  |  [optional]



