
# MessageIdentification1

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  | 
**creDtTm** | **String** |  | 



