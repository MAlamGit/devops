
# Organisation12

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fullLglNm** | **String** |  | 
**tradgNm** | **String** |  |  [optional]
**ctryOfOpr** | **String** |  | 
**regnDt** | **String** |  |  [optional]



