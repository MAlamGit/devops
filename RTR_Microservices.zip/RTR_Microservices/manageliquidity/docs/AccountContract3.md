
# AccountContract3

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**trgtGoLiveDt** | **String** |  |  [optional]
**trgtClsgDt** | **String** |  |  [optional]
**goLiveDt** | **String** |  |  [optional]
**clsgDt** | **String** |  |  [optional]
**urgcyFlg** | **String** |  |  [optional]
**rmvlInd** | **String** |  |  [optional]



