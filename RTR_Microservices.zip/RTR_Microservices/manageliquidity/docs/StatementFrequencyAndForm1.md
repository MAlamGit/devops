
# StatementFrequencyAndForm1

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**dlvryAdr** | **String** |  | 



