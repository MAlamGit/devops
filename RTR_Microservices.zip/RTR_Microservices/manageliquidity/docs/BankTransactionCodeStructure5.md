
# BankTransactionCodeStructure5

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cd** | **String** |  | 



