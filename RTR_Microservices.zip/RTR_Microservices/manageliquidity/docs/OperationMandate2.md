
# OperationMandate2

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  | 
**reqrdSgntrNb** | **String** |  | 
**sgntrOrdrInd** | **String** |  | 
**startDt** | **String** |  |  [optional]
**endDt** | **String** |  |  [optional]



