
# Group1

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**grpId** | **String** |  | 



