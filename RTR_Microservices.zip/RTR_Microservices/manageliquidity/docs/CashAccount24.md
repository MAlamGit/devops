
# CashAccount24

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ccy** | **String** |  |  [optional]
**nm** | **String** |  |  [optional]



