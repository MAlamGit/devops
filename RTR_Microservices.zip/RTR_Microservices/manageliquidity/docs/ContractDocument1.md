
# ContractDocument1

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ref** | **String** |  | 
**sgnOffDt** | **String** |  |  [optional]
**vrsn** | **String** |  |  [optional]



