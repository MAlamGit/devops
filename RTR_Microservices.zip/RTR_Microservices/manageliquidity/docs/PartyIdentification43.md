
# PartyIdentification43

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nm** | **String** |  |  [optional]
**ctryOfRes** | **String** |  |  [optional]



