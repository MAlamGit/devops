
# Restriction1

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**vldFr** | **String** |  | 
**vldUntil** | **String** |  |  [optional]



