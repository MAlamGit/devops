
# SupplementaryData1

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**plcAndNm** | **String** |  |  [optional]



