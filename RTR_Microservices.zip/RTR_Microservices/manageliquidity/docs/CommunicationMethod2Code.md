
# CommunicationMethod2Code

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------



