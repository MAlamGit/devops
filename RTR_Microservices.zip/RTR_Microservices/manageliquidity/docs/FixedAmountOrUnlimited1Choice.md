
# FixedAmountOrUnlimited1Choice

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**notLtd** | **String** |  | 



