
# CustomerAccount5

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nm** | **String** |  |  [optional]
**ccy** | **String** |  | 
**mnthlyPmtVal** | **String** |  |  [optional]
**mnthlyRcvdVal** | **String** |  |  [optional]
**mnthlyTxNb** | **String** |  |  [optional]
**avrgBal** | **String** |  |  [optional]
**acctPurp** | **String** |  |  [optional]
**flrNtfctnAmt** | **String** |  |  [optional]
**clngNtfctnAmt** | **String** |  |  [optional]
**clsgDt** | **String** |  |  [optional]



