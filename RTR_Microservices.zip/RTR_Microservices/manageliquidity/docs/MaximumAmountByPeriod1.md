
# MaximumAmountByPeriod1

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nbOfDays** | **String** |  | 



