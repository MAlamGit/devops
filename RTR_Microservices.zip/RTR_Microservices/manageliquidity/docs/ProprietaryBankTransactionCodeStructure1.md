
# ProprietaryBankTransactionCodeStructure1

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cd** | **String** |  | 
**issr** | **String** |  |  [optional]



