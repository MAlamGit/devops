
# BankTransactionCodeStructure6

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cd** | **String** |  | 
**subFmlyCd** | **String** |  | 



