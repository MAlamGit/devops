
# Party11Choice

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------



