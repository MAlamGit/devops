
# CommunicationMethod2Choice

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**prtry** | **String** |  | 



