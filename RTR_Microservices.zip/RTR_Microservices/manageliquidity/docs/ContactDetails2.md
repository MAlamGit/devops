
# ContactDetails2

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nm** | **String** |  |  [optional]
**phneNb** | **String** |  |  [optional]
**mobNb** | **String** |  |  [optional]
**faxNb** | **String** |  |  [optional]
**emailAdr** | **String** |  |  [optional]
**othr** | **String** |  |  [optional]



