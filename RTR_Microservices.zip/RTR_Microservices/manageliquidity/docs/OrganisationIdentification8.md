
# OrganisationIdentification8

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**anyBIC** | **String** |  |  [optional]



