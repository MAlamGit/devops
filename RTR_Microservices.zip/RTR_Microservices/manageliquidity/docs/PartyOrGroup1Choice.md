
# PartyOrGroup1Choice

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**grpId** | **String** |  | 



