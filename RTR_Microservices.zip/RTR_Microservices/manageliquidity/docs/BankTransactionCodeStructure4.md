
# BankTransactionCodeStructure4

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------



