# swagger-java-client

## Requirements

Building the API client library requires [Maven](https://maven.apache.org/) to be installed.

## Installation

To install the API client library to your local Maven repository, simply execute:

```shell
mvn install
```

To deploy it to a remote Maven repository instead, configure the settings of the repository and execute:

```shell
mvn deploy
```

Refer to the [official documentation](https://maven.apache.org/plugins/maven-deploy-plugin/usage.html) for more information.

### Maven users

Add this dependency to your project's POM:

```xml
<dependency>
    <groupId>io.swagger</groupId>
    <artifactId>swagger-java-client</artifactId>
    <version>1.0.0</version>
    <scope>compile</scope>
</dependency>
```

### Gradle users

Add this dependency to your project's build file:

```groovy
compile "io.swagger:swagger-java-client:1.0.0"
```

### Others

At first generate the JAR by executing:

    mvn package

Then manually install the following JARs:

* target/swagger-java-client-1.0.0.jar
* target/lib/*.jar

## Getting Started

Please follow the [installation](#installation) instruction and execute the following Java code:

```java

import io.swagger.client.*;
import io.swagger.client.auth.*;
import io.swagger.client.model.*;
import io.swagger.client.api.DefaultApi;

import java.io.File;
import java.util.*;

public class DefaultApiExample {

    public static void main(String[] args) {
        
        DefaultApi apiInstance = new DefaultApi();
        Document document = new Document(); // Document | Document
        try {
            InlineResponse200 result = apiInstance.createPayment(document);
            System.out.println(result);
        } catch (ApiException e) {
            System.err.println("Exception when calling DefaultApi#createPayment");
            e.printStackTrace();
        }
    }
}

```

## Documentation for API Endpoints

All URIs are relative to *http://localhost/manageLiquidityAccount/V1/*

Class | Method | HTTP request | Description
------------ | ------------- | ------------- | -------------
*DefaultApi* | [**createPayment**](docs/DefaultApi.md#createPayment) | **POST** /manageLiquidityAccount | Create a new payment


## Documentation for Models

 - [AccountContract3](docs/AccountContract3.md)
 - [AccountForAction1](docs/AccountForAction1.md)
 - [AccountIdentification4Choice](docs/AccountIdentification4Choice.md)
 - [AccountReport15](docs/AccountReport15.md)
 - [AccountReportV02](docs/AccountReportV02.md)
 - [AccountSchemeName1Choice](docs/AccountSchemeName1Choice.md)
 - [AccountStatus3Code](docs/AccountStatus3Code.md)
 - [ActiveCurrencyAndAmount](docs/ActiveCurrencyAndAmount.md)
 - [AdditionalDetails](docs/AdditionalDetails.md)
 - [AddressType2Code](docs/AddressType2Code.md)
 - [Authorisation2](docs/Authorisation2.md)
 - [BankTransactionCodeStructure4](docs/BankTransactionCodeStructure4.md)
 - [BankTransactionCodeStructure5](docs/BankTransactionCodeStructure5.md)
 - [BankTransactionCodeStructure6](docs/BankTransactionCodeStructure6.md)
 - [BranchAndFinancialInstitutionIdentification5](docs/BranchAndFinancialInstitutionIdentification5.md)
 - [BranchData2](docs/BranchData2.md)
 - [CashAccount24](docs/CashAccount24.md)
 - [CashAccountType2Choice](docs/CashAccountType2Choice.md)
 - [Channel2Choice](docs/Channel2Choice.md)
 - [ClearingSystemIdentification2Choice](docs/ClearingSystemIdentification2Choice.md)
 - [ClearingSystemMemberIdentification2](docs/ClearingSystemMemberIdentification2.md)
 - [CodeOrProprietary1Choice](docs/CodeOrProprietary1Choice.md)
 - [CommunicationFormat1Choice](docs/CommunicationFormat1Choice.md)
 - [CommunicationMethod2Choice](docs/CommunicationMethod2Choice.md)
 - [CommunicationMethod2Code](docs/CommunicationMethod2Code.md)
 - [CommunicationMethod3Code](docs/CommunicationMethod3Code.md)
 - [ContactDetails2](docs/ContactDetails2.md)
 - [ContractDocument1](docs/ContractDocument1.md)
 - [CustomerAccount5](docs/CustomerAccount5.md)
 - [DateAndPlaceOfBirth](docs/DateAndPlaceOfBirth.md)
 - [Document](docs/Document.md)
 - [DocumentRsp](docs/DocumentRsp.md)
 - [Error](docs/Error.md)
 - [ErrorResponse](docs/ErrorResponse.md)
 - [FinancialIdentificationSchemeName1Choice](docs/FinancialIdentificationSchemeName1Choice.md)
 - [FinancialInstitutionIdentification8](docs/FinancialInstitutionIdentification8.md)
 - [FixedAmountOrUnlimited1Choice](docs/FixedAmountOrUnlimited1Choice.md)
 - [Frequency7Code](docs/Frequency7Code.md)
 - [GenericAccountIdentification1](docs/GenericAccountIdentification1.md)
 - [GenericFinancialIdentification1](docs/GenericFinancialIdentification1.md)
 - [GenericIdentification1](docs/GenericIdentification1.md)
 - [GenericIdentification13](docs/GenericIdentification13.md)
 - [GenericOrganisationIdentification1](docs/GenericOrganisationIdentification1.md)
 - [GenericPersonIdentification1](docs/GenericPersonIdentification1.md)
 - [Group1](docs/Group1.md)
 - [InlineResponse200](docs/InlineResponse200.md)
 - [MaximumAmountByPeriod1](docs/MaximumAmountByPeriod1.md)
 - [MessageHeader2](docs/MessageHeader2.md)
 - [MessageIdentification1](docs/MessageIdentification1.md)
 - [NamePrefix1Code](docs/NamePrefix1Code.md)
 - [OperationMandate2](docs/OperationMandate2.md)
 - [Organisation12](docs/Organisation12.md)
 - [OrganisationIdentification8](docs/OrganisationIdentification8.md)
 - [OrganisationIdentificationSchemeName1Choice](docs/OrganisationIdentificationSchemeName1Choice.md)
 - [OriginalMessageAndIssuer1](docs/OriginalMessageAndIssuer1.md)
 - [Party11Choice](docs/Party11Choice.md)
 - [PartyAndAuthorisation1](docs/PartyAndAuthorisation1.md)
 - [PartyAndCertificate2](docs/PartyAndCertificate2.md)
 - [PartyAndSignature2](docs/PartyAndSignature2.md)
 - [PartyIdentification40](docs/PartyIdentification40.md)
 - [PartyIdentification43](docs/PartyIdentification43.md)
 - [PartyOrGroup1Choice](docs/PartyOrGroup1Choice.md)
 - [PersonIdentification5](docs/PersonIdentification5.md)
 - [PersonIdentificationSchemeName1Choice](docs/PersonIdentificationSchemeName1Choice.md)
 - [PointerToErrorResponse](docs/PointerToErrorResponse.md)
 - [PostalAddress6](docs/PostalAddress6.md)
 - [ProprietaryBankTransactionCodeStructure1](docs/ProprietaryBankTransactionCodeStructure1.md)
 - [ProprietaryData3](docs/ProprietaryData3.md)
 - [Receipt1](docs/Receipt1.md)
 - [ReceiptV03](docs/ReceiptV03.md)
 - [References5](docs/References5.md)
 - [RequestHandling](docs/RequestHandling.md)
 - [RequestType1Code](docs/RequestType1Code.md)
 - [RequestType2Choice](docs/RequestType2Choice.md)
 - [RequestType2Code](docs/RequestType2Code.md)
 - [Restriction1](docs/Restriction1.md)
 - [StatementFrequencyAndForm1](docs/StatementFrequencyAndForm1.md)
 - [SupplementaryData1](docs/SupplementaryData1.md)
 - [SupplementaryDataEnvelope1](docs/SupplementaryDataEnvelope1.md)
 - [UseCases1Code](docs/UseCases1Code.md)


## Documentation for Authorization

All endpoints do not require authorization.
Authentication schemes defined for the API:

## Recommendation

It's recommended to create an instance of `ApiClient` per thread in a multithreaded environment to avoid any potential issues.

## Author



