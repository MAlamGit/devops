package io.swagger.client.fixtures;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;

public class ReadFixtures {
	private ReadFixtures() {
	}

	/*
	 * Method to read request JSON for junit testing
	 * 
	 * @path src/test/resources/fixtures/request.json
	 */
	public static String readFixture(String path) throws IOException {
		byte[] reqmsg = Files.readAllBytes(Paths.get("src/test/resources/fixtures/" + path));
		return new String(reqmsg, StandardCharsets.UTF_8);

	}

}
