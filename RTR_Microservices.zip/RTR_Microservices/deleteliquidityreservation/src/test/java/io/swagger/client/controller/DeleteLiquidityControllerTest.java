package io.swagger.client.controller;

import java.net.URI;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;

import io.swagger.client.fixtures.ReadFixtures;
import io.swagger.client.model.Document;
import junit.framework.Assert;

@SpringBootTest
@RunWith(MockitoJUnitRunner.class)
/*Junit Test case for Delete Liquidity Microservice
 * 
 * @link io.swagger.client.controller.DeleteLiquidityController
 */
public class DeleteLiquidityControllerTest {
	@InjectMocks
	DeleteLiquidityController controller;
	@Mock
	Document documentObject;

	@Mock
	ObjectMapper objectMapper;
	@Mock
	HttpHeaders headers;

	@Mock
	XmlMapper mapper;
	private MockMvc mockMvc;

	@Before
	public void initMocks() {
		MockitoAnnotations.initMocks(this);
		this.mockMvc = MockMvcBuilders.standaloneSetup(controller).build();
	}

	@Test
	public void Successcenario() throws Exception {

		RestTemplate restTemplate = new RestTemplate();
		final String baseUrl = "http://localhost:8095/deleteLiquidityReservations/V1/deleteLiquidity";
		URI uri = new URI(baseUrl);

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		String data = new String(ReadFixtures.readFixture("request.json").getBytes(), "UTF-8");
		HttpEntity<String> request = new HttpEntity<String>(data, headers);

		try {
			ResponseEntity<String> result = restTemplate.postForEntity(uri, request, String.class);
			Assert.assertEquals(200, result.getStatusCodeValue());
		} catch (HttpClientErrorException ex) {
			Assert.assertEquals(400, ex.getRawStatusCode());
			Assert.assertEquals(true, ex.getResponseBodyAsString().contains("Missing request header"));

		}

	}

}
