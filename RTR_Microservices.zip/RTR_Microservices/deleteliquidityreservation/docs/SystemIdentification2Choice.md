
# SystemIdentification2Choice

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ctry** | **String** |  | 



