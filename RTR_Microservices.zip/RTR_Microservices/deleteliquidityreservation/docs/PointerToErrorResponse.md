
# PointerToErrorResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**errorResponse** | [**ErrorResponse**](ErrorResponse.md) |  |  [optional]



