
# RequestType2Code

## Enum


* `RT11` (value: `"RT11"`)

* `RT12` (value: `"RT12"`)

* `RT13` (value: `"RT13"`)

* `RT14` (value: `"RT14"`)

* `RT15` (value: `"RT15"`)



