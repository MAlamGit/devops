
# ReservationIdentification1

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**rsvatnId** | **String** |  |  [optional]



