
# GenericFinancialIdentification1

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  | 
**issr** | **String** |  |  [optional]



