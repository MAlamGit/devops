
# DeleteReservationV03

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------



