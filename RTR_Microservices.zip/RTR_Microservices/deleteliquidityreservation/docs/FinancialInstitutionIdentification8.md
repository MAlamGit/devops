
# FinancialInstitutionIdentification8

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**bicfi** | **String** |  |  [optional]
**nm** | **String** |  |  [optional]



