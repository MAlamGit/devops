
# MessageHeader2

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**msgId** | **String** |  | 
**creDtTm** | **String** |  |  [optional]



