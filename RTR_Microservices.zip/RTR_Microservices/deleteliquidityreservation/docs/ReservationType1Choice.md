
# ReservationType1Choice

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**prtry** | **String** |  | 



