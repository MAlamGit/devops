
# RequestHandling

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**stsCd** | **String** |  | 
**desc** | **String** |  |  [optional]



