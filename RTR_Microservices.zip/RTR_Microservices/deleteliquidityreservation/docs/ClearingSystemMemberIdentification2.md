
# ClearingSystemMemberIdentification2

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mmbId** | **String** |  | 



