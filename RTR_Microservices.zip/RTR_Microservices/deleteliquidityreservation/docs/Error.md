
# Error

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | HTTP Error codes |  [optional]
**severity** | [**SeverityEnum**](#SeverityEnum) |  |  [optional]
**errordescription** | **String** | HTTP error standard description |  [optional]
**additionalDetails** | [**List&lt;AdditionalDetails&gt;**](AdditionalDetails.md) |  |  [optional]


<a name="SeverityEnum"></a>
## Enum: SeverityEnum
Name | Value
---- | -----
ERROR | &quot;error&quot;
WARNING | &quot;warning&quot;
INFO | &quot;Info&quot;



