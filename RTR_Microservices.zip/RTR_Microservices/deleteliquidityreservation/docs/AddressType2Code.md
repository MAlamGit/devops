
# AddressType2Code

## Enum


* `ADDR` (value: `"ADDR"`)

* `PBOX` (value: `"PBOX"`)

* `HOME` (value: `"HOME"`)

* `BIZZ` (value: `"BIZZ"`)

* `MLTO` (value: `"MLTO"`)

* `DLVY` (value: `"DLVY"`)



