
# ReservationType2Code

## Enum


* `CARE` (value: `"CARE"`)

* `UPAR` (value: `"UPAR"`)

* `NSSR` (value: `"NSSR"`)

* `HPAR` (value: `"HPAR"`)

* `THRE` (value: `"THRE"`)

* `BLKD` (value: `"BLKD"`)



