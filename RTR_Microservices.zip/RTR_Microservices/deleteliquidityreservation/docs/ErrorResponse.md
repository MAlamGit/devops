
# ErrorResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fatalError** | **Boolean** |  |  [optional]
**error** | [**Error**](Error.md) |  |  [optional]



