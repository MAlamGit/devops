
# PostalAddress6

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**dept** | **String** |  |  [optional]
**subDept** | **String** |  |  [optional]
**strtNm** | **String** |  |  [optional]
**bldgNb** | **String** |  |  [optional]
**pstCd** | **String** |  |  [optional]
**twnNm** | **String** |  |  [optional]
**ctrySubDvsn** | **String** |  |  [optional]
**ctry** | **String** |  |  [optional]



