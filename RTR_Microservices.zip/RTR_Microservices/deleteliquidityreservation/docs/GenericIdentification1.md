
# GenericIdentification1

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  | 
**schmeNm** | **String** |  |  [optional]
**issr** | **String** |  |  [optional]



