
# AdditionalDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**errorCode** | **String** | backend error code |  [optional]
**severity** | **String** | Error severity from back end system |  [optional]
**status** | **String** | error status which can be System name+module name+Method Name+Varriable |  [optional]
**description** | **String** |  |  [optional]



