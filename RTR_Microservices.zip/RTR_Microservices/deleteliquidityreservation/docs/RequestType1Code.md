
# RequestType1Code

## Enum


* `RT01` (value: `"RT01"`)

* `RT02` (value: `"RT02"`)

* `RT03` (value: `"RT03"`)

* `RT04` (value: `"RT04"`)

* `RT05` (value: `"RT05"`)



