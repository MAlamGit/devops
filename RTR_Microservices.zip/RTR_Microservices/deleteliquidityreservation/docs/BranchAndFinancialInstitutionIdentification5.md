
# BranchAndFinancialInstitutionIdentification5

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------



