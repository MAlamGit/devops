
# ReceiptV03

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------



