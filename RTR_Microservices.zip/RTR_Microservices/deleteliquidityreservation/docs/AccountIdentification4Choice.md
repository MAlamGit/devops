
# AccountIdentification4Choice

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**iban** | **String** |  | 



