# swagger-java-client

## Requirements

Building the API client library requires [Maven](https://maven.apache.org/) to be installed.

## Installation

To install the API client library to your local Maven repository, simply execute:

```shell
mvn install
```

To deploy it to a remote Maven repository instead, configure the settings of the repository and execute:

```shell
mvn deploy
```

Refer to the [official documentation](https://maven.apache.org/plugins/maven-deploy-plugin/usage.html) for more information.

### Maven users

Add this dependency to your project's POM:

```xml
<dependency>
    <groupId>io.swagger</groupId>
    <artifactId>swagger-java-client</artifactId>
    <version>1.0.0</version>
    <scope>compile</scope>
</dependency>
```

### Gradle users

Add this dependency to your project's build file:

```groovy
compile "io.swagger:swagger-java-client:1.0.0"
```

### Others

At first generate the JAR by executing:

    mvn package

Then manually install the following JARs:

* target/swagger-java-client-1.0.0.jar
* target/lib/*.jar

## Getting Started

Please follow the [installation](#installation) instruction and execute the following Java code:

```java

import io.swagger.client.*;
import io.swagger.client.auth.*;
import io.swagger.client.model.*;
import io.swagger.client.api.DefaultApi;

import java.io.File;
import java.util.*;

public class DefaultApiExample {

    public static void main(String[] args) {
        
        DefaultApi apiInstance = new DefaultApi();
        Document document = new Document(); // Document | Document
        try {
            InlineResponse200 result = apiInstance.createPayment(document);
            System.out.println(result);
        } catch (ApiException e) {
            System.err.println("Exception when calling DefaultApi#createPayment");
            e.printStackTrace();
        }
    }
}

```

## Documentation for API Endpoints

All URIs are relative to *http://localhost/DeleteLiquidity/V1/*

Class | Method | HTTP request | Description
------------ | ------------- | ------------- | -------------
*DefaultApi* | [**createPayment**](docs/DefaultApi.md#createPayment) | **POST** /deleteLiquidityReservations | Create a new payment


## Documentation for Models

 - [AccountIdentification4Choice](docs/AccountIdentification4Choice.md)
 - [AccountSchemeName1Choice](docs/AccountSchemeName1Choice.md)
 - [AdditionalDetails](docs/AdditionalDetails.md)
 - [AddressType2Code](docs/AddressType2Code.md)
 - [BranchAndFinancialInstitutionIdentification5](docs/BranchAndFinancialInstitutionIdentification5.md)
 - [BranchData2](docs/BranchData2.md)
 - [ClearingSystemIdentification2Choice](docs/ClearingSystemIdentification2Choice.md)
 - [ClearingSystemMemberIdentification2](docs/ClearingSystemMemberIdentification2.md)
 - [DeleteReservationV03](docs/DeleteReservationV03.md)
 - [Document](docs/Document.md)
 - [DocumentRsp](docs/DocumentRsp.md)
 - [Error](docs/Error.md)
 - [ErrorResponse](docs/ErrorResponse.md)
 - [FinancialIdentificationSchemeName1Choice](docs/FinancialIdentificationSchemeName1Choice.md)
 - [FinancialInstitutionIdentification8](docs/FinancialInstitutionIdentification8.md)
 - [GenericAccountIdentification1](docs/GenericAccountIdentification1.md)
 - [GenericFinancialIdentification1](docs/GenericFinancialIdentification1.md)
 - [GenericIdentification1](docs/GenericIdentification1.md)
 - [InlineResponse200](docs/InlineResponse200.md)
 - [MarketInfrastructureIdentification1Choice](docs/MarketInfrastructureIdentification1Choice.md)
 - [MessageHeader1](docs/MessageHeader1.md)
 - [MessageHeader2](docs/MessageHeader2.md)
 - [OriginalMessageAndIssuer1](docs/OriginalMessageAndIssuer1.md)
 - [PointerToErrorResponse](docs/PointerToErrorResponse.md)
 - [PostalAddress6](docs/PostalAddress6.md)
 - [Receipt1](docs/Receipt1.md)
 - [ReceiptV03](docs/ReceiptV03.md)
 - [RequestHandling](docs/RequestHandling.md)
 - [RequestType1Code](docs/RequestType1Code.md)
 - [RequestType2Choice](docs/RequestType2Choice.md)
 - [RequestType2Code](docs/RequestType2Code.md)
 - [ReservationIdentification1](docs/ReservationIdentification1.md)
 - [ReservationType1Choice](docs/ReservationType1Choice.md)
 - [ReservationType2Code](docs/ReservationType2Code.md)
 - [SystemIdentification2Choice](docs/SystemIdentification2Choice.md)


## Documentation for Authorization

All endpoints do not require authorization.
Authentication schemes defined for the API:

## Recommendation

It's recommended to create an instance of `ApiClient` per thread in a multithreaded environment to avoid any potential issues.

## Author



